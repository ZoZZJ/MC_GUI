/****************************************************************************
** Meta object code from reading C++ file 'XyPlatform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../XyPlatform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'XyPlatform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_XyPlatform_t {
    QByteArrayData data[40];
    char stringdata0[782];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_XyPlatform_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_XyPlatform_t qt_meta_stringdata_XyPlatform = {
    {
QT_MOC_LITERAL(0, 0, 10), // "XyPlatform"
QT_MOC_LITERAL(1, 11, 13), // "errorOccurred"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 8), // "errorMsg"
QT_MOC_LITERAL(4, 35, 27), // "ChangePlatformEnabledStatus"
QT_MOC_LITERAL(5, 63, 10), // "handleStop"
QT_MOC_LITERAL(6, 74, 6), // "axisId"
QT_MOC_LITERAL(7, 81, 21), // "onAxisPositionUpdated"
QT_MOC_LITERAL(8, 103, 8), // "position"
QT_MOC_LITERAL(9, 112, 21), // "onAxisVelocityUpdated"
QT_MOC_LITERAL(10, 134, 8), // "velocity"
QT_MOC_LITERAL(11, 143, 18), // "onAxisAngleUpdated"
QT_MOC_LITERAL(12, 162, 5), // "Angle"
QT_MOC_LITERAL(13, 168, 25), // "onAxisAccelerationUpdated"
QT_MOC_LITERAL(14, 194, 12), // "acceleration"
QT_MOC_LITERAL(15, 207, 12), // "updateStatus"
QT_MOC_LITERAL(16, 220, 23), // "on_CommutButton_clicked"
QT_MOC_LITERAL(17, 244, 20), // "onRadioButtonClicked"
QT_MOC_LITERAL(18, 265, 16), // "QAbstractButton*"
QT_MOC_LITERAL(19, 282, 6), // "button"
QT_MOC_LITERAL(20, 289, 29), // "on_VelocityPushButton_clicked"
QT_MOC_LITERAL(21, 319, 25), // "on_OpenCardbutton_clicked"
QT_MOC_LITERAL(22, 345, 26), // "on_CloseCardbutton_clicked"
QT_MOC_LITERAL(23, 372, 31), // "on_StopMotionSoftButton_clicked"
QT_MOC_LITERAL(24, 404, 24), // "on_RightButton_4_clicked"
QT_MOC_LITERAL(25, 429, 23), // "on_LeftButton_4_clicked"
QT_MOC_LITERAL(26, 453, 24), // "on_RightButton_1_clicked"
QT_MOC_LITERAL(27, 478, 23), // "on_LeftButton_1_clicked"
QT_MOC_LITERAL(28, 502, 24), // "on_RightButton_3_clicked"
QT_MOC_LITERAL(29, 527, 23), // "on_LeftButton_3_clicked"
QT_MOC_LITERAL(30, 551, 24), // "on_RightButton_2_clicked"
QT_MOC_LITERAL(31, 576, 23), // "on_LeftButton_2_clicked"
QT_MOC_LITERAL(32, 600, 22), // "on_RightButton_clicked"
QT_MOC_LITERAL(33, 623, 21), // "on_LeftButton_clicked"
QT_MOC_LITERAL(34, 645, 19), // "on_UpButton_clicked"
QT_MOC_LITERAL(35, 665, 21), // "on_DownButton_clicked"
QT_MOC_LITERAL(36, 687, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(37, 709, 23), // "on_LeftButton_9_clicked"
QT_MOC_LITERAL(38, 733, 24), // "on_LeftButton_10_clicked"
QT_MOC_LITERAL(39, 758, 23) // "on_LeftButton_7_clicked"

    },
    "XyPlatform\0errorOccurred\0\0errorMsg\0"
    "ChangePlatformEnabledStatus\0handleStop\0"
    "axisId\0onAxisPositionUpdated\0position\0"
    "onAxisVelocityUpdated\0velocity\0"
    "onAxisAngleUpdated\0Angle\0"
    "onAxisAccelerationUpdated\0acceleration\0"
    "updateStatus\0on_CommutButton_clicked\0"
    "onRadioButtonClicked\0QAbstractButton*\0"
    "button\0on_VelocityPushButton_clicked\0"
    "on_OpenCardbutton_clicked\0"
    "on_CloseCardbutton_clicked\0"
    "on_StopMotionSoftButton_clicked\0"
    "on_RightButton_4_clicked\0"
    "on_LeftButton_4_clicked\0"
    "on_RightButton_1_clicked\0"
    "on_LeftButton_1_clicked\0"
    "on_RightButton_3_clicked\0"
    "on_LeftButton_3_clicked\0"
    "on_RightButton_2_clicked\0"
    "on_LeftButton_2_clicked\0on_RightButton_clicked\0"
    "on_LeftButton_clicked\0on_UpButton_clicked\0"
    "on_DownButton_clicked\0on_pushButton_clicked\0"
    "on_LeftButton_9_clicked\0"
    "on_LeftButton_10_clicked\0"
    "on_LeftButton_7_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_XyPlatform[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  164,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  167,    2, 0x08 /* Private */,
       5,    1,  168,    2, 0x08 /* Private */,
       7,    2,  171,    2, 0x08 /* Private */,
       9,    2,  176,    2, 0x08 /* Private */,
      11,    2,  181,    2, 0x08 /* Private */,
      13,    2,  186,    2, 0x08 /* Private */,
      15,    0,  191,    2, 0x08 /* Private */,
      16,    0,  192,    2, 0x08 /* Private */,
      17,    1,  193,    2, 0x08 /* Private */,
      20,    0,  196,    2, 0x08 /* Private */,
      21,    0,  197,    2, 0x08 /* Private */,
      22,    0,  198,    2, 0x08 /* Private */,
      23,    0,  199,    2, 0x08 /* Private */,
      24,    0,  200,    2, 0x08 /* Private */,
      25,    0,  201,    2, 0x08 /* Private */,
      26,    0,  202,    2, 0x08 /* Private */,
      27,    0,  203,    2, 0x08 /* Private */,
      28,    0,  204,    2, 0x08 /* Private */,
      29,    0,  205,    2, 0x08 /* Private */,
      30,    0,  206,    2, 0x08 /* Private */,
      31,    0,  207,    2, 0x08 /* Private */,
      32,    0,  208,    2, 0x08 /* Private */,
      33,    0,  209,    2, 0x08 /* Private */,
      34,    0,  210,    2, 0x08 /* Private */,
      35,    0,  211,    2, 0x08 /* Private */,
      36,    0,  212,    2, 0x08 /* Private */,
      37,    0,  213,    2, 0x08 /* Private */,
      38,    0,  214,    2, 0x08 /* Private */,
      39,    0,  215,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Float,    6,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Float,    6,   10,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,    6,   12,
    QMetaType::Void, QMetaType::Int, QMetaType::Float,    6,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void XyPlatform::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<XyPlatform *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->errorOccurred((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->ChangePlatformEnabledStatus(); break;
        case 2: _t->handleStop((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->onAxisPositionUpdated((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 4: _t->onAxisVelocityUpdated((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 5: _t->onAxisAngleUpdated((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 6: _t->onAxisAccelerationUpdated((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 7: _t->updateStatus(); break;
        case 8: _t->on_CommutButton_clicked(); break;
        case 9: _t->onRadioButtonClicked((*reinterpret_cast< QAbstractButton*(*)>(_a[1]))); break;
        case 10: _t->on_VelocityPushButton_clicked(); break;
        case 11: _t->on_OpenCardbutton_clicked(); break;
        case 12: _t->on_CloseCardbutton_clicked(); break;
        case 13: _t->on_StopMotionSoftButton_clicked(); break;
        case 14: _t->on_RightButton_4_clicked(); break;
        case 15: _t->on_LeftButton_4_clicked(); break;
        case 16: _t->on_RightButton_1_clicked(); break;
        case 17: _t->on_LeftButton_1_clicked(); break;
        case 18: _t->on_RightButton_3_clicked(); break;
        case 19: _t->on_LeftButton_3_clicked(); break;
        case 20: _t->on_RightButton_2_clicked(); break;
        case 21: _t->on_LeftButton_2_clicked(); break;
        case 22: _t->on_RightButton_clicked(); break;
        case 23: _t->on_LeftButton_clicked(); break;
        case 24: _t->on_UpButton_clicked(); break;
        case 25: _t->on_DownButton_clicked(); break;
        case 26: _t->on_pushButton_clicked(); break;
        case 27: _t->on_LeftButton_9_clicked(); break;
        case 28: _t->on_LeftButton_10_clicked(); break;
        case 29: _t->on_LeftButton_7_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAbstractButton* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (XyPlatform::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&XyPlatform::errorOccurred)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject XyPlatform::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_XyPlatform.data,
    qt_meta_data_XyPlatform,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *XyPlatform::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *XyPlatform::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_XyPlatform.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int XyPlatform::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    }
    return _id;
}

// SIGNAL 0
void XyPlatform::errorOccurred(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
